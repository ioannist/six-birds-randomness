



review the response if the ticket landed in the repo as expected (zipped repo attached), if not, fold change requests into the next ticket. now, proceed with this repo agent ticket:

## Ticket W1 — Bibliography scaffold and citation key lock

**Goal**
Create the minimal bibliography file and stable citation keys before prose writing starts.

**Agent actions**

* Populate `paper/references.bib` with the small citation set we expect to use
* Keep it tight: only clearly relevant items
* Include, at minimum:

  * Six Birds foundations
  * PICA
  * To Notch a Stone
  * optional Protocol Trap / Quantum only if cited later
  * information bottleneck
  * computational mechanics / predictive-state reference
  * one-wayness / random-oracle reference
  * a classic lumpability reference if used
* Add a citation-key inventory comment block at top of `references.bib`

**Pass criteria**

* Paper still compiles with bibliography hook live
* Citation keys are stable and ready for prose tickets

**Repo agent reports**

* citation keys added
* compile status
* undefined citation count should be zero at this stage if only stubs are present

---










review the response if the ticket landed in the repo as expected (zipped repo attached), if not, fold change requests into the next ticket. now, proceed with this repo agent ticket:

## Ticket W2 — Front matter, abstract, and introduction

**Goal**
Insert the exact title, abstract, and introduction text.

**What I will provide**

* full abstract
* full introduction
* exact paragraph listing the six primitives near the beginning
* the title line
* any front-matter note we want under the title

**Agent actions**

* Insert the text verbatim except for TeX-safe escaping and line wrapping
* Add labels for the main theorem/definition section references if the intro points ahead
* Keep author block as clean placeholder if metadata is still unavailable

**Pass criteria**

* Paper compiles
* Introduction appears in final layout
* six primitives paragraph is placed within the first two pages

**Repo agent reports**

* modified files
* compile status, page count
* labels/citations introduced
* any overfull boxes caused by prose

---









review the response if the ticket landed in the repo as expected (zipped repo attached), if not, fold change requests into the next ticket. now, proceed with this repo agent ticket:

## Ticket W3 — Six Birds recap and exact closure-deficit formalism

**Goal**
Write the setup section and the core formal section.

**What I will provide**

* exact text for:

  * layer / packaging / staging setup
  * the definition of micro-closure deficit
  * the decomposition equation
  * explanation of intrinsic term vs closure deficit
  * relation to sufficiency / lumpability
* exact displayed equations and theorem-style statements

**Agent actions**

* Insert text into:

  * `paper/sections/02_setup.tex`
  * `paper/sections/03_closure_deficit.tex`
* Create theorem/definition environments if needed
* Add labels for equations, definitions, and propositions

**Pass criteria**

* Paper compiles
* equation numbering and references work
* theorem environments render cleanly

**Repo agent reports**

* files modified
* equation / theorem labels added
* compile status and warnings

---








review the response if the ticket landed in the repo as expected (zipped repo attached), if not, fold change requests into the next ticket. now, proceed with this repo agent ticket:

## Ticket W4 — Computable diagnostics, route mismatch, and budgeted randomness

**Goal**
Write the bridge section that connects the exact quantity to observables and proxies.

**What I will provide**

* exact prose for:

  * route mismatch as computable non-closure diagnostic
  * predictive-gap connection to *To Notch a Stone*
  * budgeted randomness / limited-memory predictors
  * scope note separating randomness from irreversibility and novelty
* any small conceptual table text

**Agent actions**

* Insert exact text into `paper/sections/04_diagnostics.tex`
* Create any small LaTeX table if supplied
* Ensure cross-references to W2/W3 sections compile

**Pass criteria**

* Paper compiles
* all new citations resolve
* any table renders cleanly

**Repo agent reports**

* modified files
* labels/citations added
* compile status
* table rendering notes if applicable

---









review the response if the ticket landed in the repo as expected (zipped repo attached), if not, fold change requests into the next ticket. now, proceed with this repo agent ticket:

## Ticket W5 — Publication figure and table assets from frozen artifacts

**Goal**
Build publication-ready visuals from `artifacts/final/` without rerunning experiments.

**Agent actions**

* Copy needed frozen tables into `paper/data/` or read directly from `artifacts/final/tables/`
* Create scripts under `paper/scripts/` to generate publication figures
* Generate these main-text figures:

  1. conceptual closure-deficit schematic
  2. Markov RM vs CD scatter
  3. Markov CD vs heterogeneity
  4. budget curve vs theory line
  5. hashing inversion success vs (q/2^n)
  6. hashing collision-ratio separation by distribution
* Generate appendix figures:

  * rep clustering CD vs (k)
  * rep clustering NLL vs (k)
* Output vector-first assets into `paper/figures/generated/`

**Pass criteria**

* all figure files exist and are non-empty
* paper still compiles after figure assets are added to the repo
* no experiment runner is called; only frozen artifacts are read

**Repo agent reports**

* generated figure filenames
* source tables used
* whether any manual axis or label adjustments were needed

---









review the response if the ticket landed in the repo as expected (zipped repo attached), if not, fold change requests into the next ticket. now, proceed with this repo agent ticket:

## Ticket W6 — Markov benchmark results section

**Goal**
Write the main results subsection for the controlled Markov benchmark and place its figures.

**What I will provide**

* exact prose
* exact captions
* any headline numbers to cite from frozen artifacts
* the figure ordering and labels

**Agent actions**

* Insert the text into `paper/sections/05_results_markov.tex`
* Include the appropriate figures from W5
* Add the relevant figure labels and cross-references

**Pass criteria**

* paper compiles
* Markov section reads as a complete self-contained results section
* figures and captions render cleanly

**Repo agent reports**

* modified files
* figures inserted
* compile status
* page count shift

---














review the response if the ticket landed in the repo as expected (zipped repo attached), if not, fold change requests into the next ticket. now, proceed with this repo agent ticket:

## Ticket W7 — Budget curves and hashing results section

**Goal**
Write the second main results section, covering both budgeted prediction and hashing.

**What I will provide**

* exact prose for the budget subsection
* exact prose for the hashing subsection
* exact captions
* any table text if we include a compact summary table

**Agent actions**

* Insert text into `paper/sections/06_results_budget_hashing.tex`
* Include:

  * budget curve figure
  * hashing inversion-vs-budget figure
  * hashing collision/random-lookingness figure
* Ensure the hashing section states clearly that hashing does not create entropy

**Pass criteria**

* paper compiles
* main empirical arc is now complete in manuscript form
* all cited numbers match frozen artifacts

**Repo agent reports**

* modified files
* figures/tables inserted
* compile status
* unresolved warnings if any

---











review the response if the ticket landed in the repo as expected (zipped repo attached), if not, fold change requests into the next ticket. now, proceed with this repo agent ticket:

## Ticket W8 — Discussion, scope, conclusion, and appendices

**Goal**
Finish the manuscript body and add the non-core appendices.

**What I will provide**

* exact discussion text
* exact conclusion text
* exact appendix text for:

  * auxiliary clustering result as a cautionary case
  * Lean KL bridge note
  * optional frozen-artifact / reproducibility note if needed

**Agent actions**

* Insert into:

  * `paper/sections/07_discussion.tex`
  * `paper/sections/appendix_rep_clustering.tex`
  * `paper/sections/appendix_lean.tex`
* Include appendix figures from W5 where needed
* Make sure the rep-clustering appendix is framed as auxiliary, not core evidence

**Pass criteria**

* paper compiles
* appendices render and are referenced correctly
* excluded NN runs are not presented as evidence

**Repo agent reports**

* modified files
* appendix figures inserted
* compile status and page count

---











review the response if the ticket landed in the repo as expected (zipped repo attached), if not, fold change requests into the next ticket. now, proceed with this repo agent ticket:

## Ticket W9 — Full integration, citation audit, and final polish

**Goal**
Take the complete draft from “compiles” to “submission-quality working draft.”

**Agent actions**

* Run full compile until citations and cross-refs settle
* Fix:

  * undefined refs / cites
  * broken figure placement
  * ugly page breaks
  * obvious overfull boxes
  * caption spacing problems
* Do a notation consistency pass:

  * same symbols for (X_t), (Y_t), (\Pi), (\tau), CD
* Do a citation hygiene pass:

  * no unused bib entries unless intentional
  * no missing bib entries
  * no accidental overcitation
* If author/affiliation metadata is available by then, finalize it; otherwise keep a clean placeholder block

**Pass criteria**

* full paper compiles cleanly
* zero undefined references/citations
* no serious overfull boxes
* all main and appendix figures/tables resolve
* manuscript is complete aside from optional metadata-only fields

**Repo agent reports**

* modified files
* final compile command + exit code
* final page count
* remaining warnings, if any
* list of anything still intentionally placeholder-only

---

## End state after W9

At that point we should have:

* a complete manuscript under `paper/`
* publication figures derived only from frozen evidence
* appendices in place
* citations resolved
* a clean compile path

The only things that should remain outside the writing workflow are true metadata-only items such as author affiliations, acknowledgments, and funding statements if those have not yet been supplied.

I’d start the writing phase with **W0** and then move immediately to **W1**, so the prose tickets can use stable section files and citation keys.
